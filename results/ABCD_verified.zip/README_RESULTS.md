# ABC与D同次结果包

正式引用入口：[report/metrics.json](report/metrics.json)、[T5数字及报告页码](report/T5_数字核对表.md)、[完整数值CSV](report/T5_all_numbers.csv)。
107处正文/表格数字及原图数据源已登记报告页码；PPT页码待E实际稿核对。report.docx在仓库根目录，不重复装入ZIP。
workspace/保存原始阶段产物与B/C/D01/D02清单，未重写它们；早期阶段T5仍可能保留当时未填页码状态，不能替代本包report/的正式T5。
run/保留真实无缓存运行及比对清单。原始CSV、配置和源码在仓库内，不重复打包。snapshot.json记录成员指纹、源码输入及原运行路径到成员的映射。
正式metrics在原D01全部键值之上仅添加report_evidence文档登记节；原D01 JSON在workspace/local_review/D01_candidate/outputs/保持原字节。
本包含历史回放，不代表真实人工放行、上线、外呼或因果成效。
原阶段清单使用各自工作区相对路径；从snapshot.json和run/artifact_catalog.json查成员，不把解压目录当作原工作区，也不改清单指纹迁就路径。
ZIP内旧阶段Markdown的默认命令/相对链接属于原阶段记录；查看本包以本页和正式report/索引为准。
metrics的只读属性不一定被解压工具保留；内容以成员SHA256为准。

| 内容 | 位置 |
|---|---|
| 原数据说明与许可 | [数据说明](workspace/data/README_data.md) |
| Test模型比较 | [模型表](workspace/local_review/C01_candidate/outputs/C_测试集模型比较表.md) |
| 补充规则及损失 | [T6](workspace/local_review/D01_candidate/outputs/T6_联系限制补充评价.md) |
| 建议行动图 | [F5 PNG](workspace/local_review/D02_candidate/outputs/F5_行动闭环.png) / [SVG](workspace/local_review/D02_candidate/outputs/F5_行动闭环.svg) |
